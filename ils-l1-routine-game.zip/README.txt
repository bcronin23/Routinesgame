Independent Living — Level 1 Drag & Drop (Daily Routine)
---------------------------------------------------------------
Files:
- index.html  (open this)

Quick hosting options:
1) Netlify Drop (fastest): drag this ZIP to https://app.netlify.com/drop
2) GitHub Pages: new repo -> upload index.html -> Settings -> Pages -> Deploy.
3) Google Apps Script Web App: paste HTML into HtmlService (see ChatGPT steps).

Tip for iPads: if dragging is tricky, tap the 'Tap-to-Place' button in the toolbar.
